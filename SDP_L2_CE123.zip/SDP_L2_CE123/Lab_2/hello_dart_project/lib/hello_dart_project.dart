int calculate() {
  return 8 * 7;
}
